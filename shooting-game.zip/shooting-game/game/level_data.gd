class_name LevelData
extends RefCounted

## The 3 levels shown in the menu. Each one is a list of wall rectangles plus
## enemy spawn cells, in TILE coordinates on a 48 x 27 grid (24 px tiles =
## 1152 x 648, the whole screen). The outer border is added automatically, so
## keep walls and spawns inside columns 1..46 and rows 1..25.

const TILE := 24
const ARENA := Vector2i(48, 27)

const LEVELS: Array[Dictionary] = [
	{
		"name": "LEVEL 1 - OPEN ARENA",
		"desc": "Nowhere to hide. Three grunts.",
		"player_cell": Vector2i(24, 13),
		"walls": [],
		"spawns": [
			{"type": "grunt", "cell": Vector2i(8, 5)},
			{"type": "grunt", "cell": Vector2i(39, 6)},
			{"type": "grunt", "cell": Vector2i(24, 21)},
		],
	},
	{
		"name": "LEVEL 2 - TAKE COVER",
		"desc": "Three blocks to duck behind. A drone joins in.",
		"player_cell": Vector2i(24, 20),
		"walls": [Rect2i(22, 6, 4, 3), Rect2i(10, 16, 5, 3), Rect2i(33, 16, 5, 3)],
		"spawns": [
			{"type": "grunt", "cell": Vector2i(8, 4)},
			{"type": "drone", "cell": Vector2i(40, 4)},
			{"type": "grunt", "cell": Vector2i(24, 11)},
		],
	},
	{
		"name": "LEVEL 3 - THE PILLARS",
		"desc": "Three long columns split the arena into lanes.",
		"player_cell": Vector2i(4, 13),
		"walls": [Rect2i(11, 3, 2, 20), Rect2i(23, 3, 2, 20), Rect2i(35, 3, 2, 20)],
		"spawns": [
			{"type": "grunt", "cell": Vector2i(17, 5)},
			{"type": "drone", "cell": Vector2i(29, 21)},
			{"type": "grunt", "cell": Vector2i(41, 8)},
			{"type": "drone", "cell": Vector2i(17, 21)},
			{"type": "grunt", "cell": Vector2i(44, 20)},
		],
	},
]

## Extra maps, not in the menu. Move an entry up into LEVELS to play it again.
const SPARE_LEVELS: Array[Dictionary] = [
	{
		"name": "LEVEL 4 - CROSSFIRE",
		"desc": "A broken cross in the middle. Watch the ricochets.",
		"player_cell": Vector2i(20, 20),
		"walls": [Rect2i(23, 4, 2, 7), Rect2i(23, 17, 2, 7), Rect2i(13, 12, 7, 2), Rect2i(28, 12, 7, 2)],
		"spawns": [
			{"type": "grunt", "cell": Vector2i(6, 6)},
			{"type": "drone", "cell": Vector2i(42, 6)},
			{"type": "grunt", "cell": Vector2i(42, 21)},
			{"type": "drone", "cell": Vector2i(6, 21)},
			{"type": "grunt", "cell": Vector2i(24, 2)},
		],
	},
	{
		"name": "LEVEL 5 - CORNERS",
		"desc": "Four corner blocks and a swarm of drones.",
		"player_cell": Vector2i(24, 13),
		"walls": [Rect2i(6, 4, 4, 4), Rect2i(38, 4, 4, 4), Rect2i(6, 19, 4, 4), Rect2i(38, 19, 4, 4)],
		"spawns": [
			{"type": "drone", "cell": Vector2i(24, 4)},
			{"type": "drone", "cell": Vector2i(24, 22)},
			{"type": "drone", "cell": Vector2i(10, 13)},
			{"type": "drone", "cell": Vector2i(38, 13)},
			{"type": "grunt", "cell": Vector2i(44, 13)},
		],
	},
	{
		"name": "LEVEL 6 - THE GAUNTLET",
		"desc": "Six walls with a gap down the middle. Run it.",
		"player_cell": Vector2i(3, 13),
		"walls": [
			Rect2i(8, 1, 2, 10), Rect2i(8, 16, 2, 9),
			Rect2i(20, 1, 2, 10), Rect2i(20, 16, 2, 9),
			Rect2i(32, 1, 2, 10), Rect2i(32, 16, 2, 9),
		],
		"spawns": [
			{"type": "grunt", "cell": Vector2i(14, 13)},
			{"type": "drone", "cell": Vector2i(26, 13)},
			{"type": "grunt", "cell": Vector2i(38, 13)},
			{"type": "drone", "cell": Vector2i(44, 5)},
			{"type": "grunt", "cell": Vector2i(44, 21)},
		],
	},
	{
		"name": "LEVEL 7 - THE HIVE",
		"desc": "A walled hive with four openings. They are inside.",
		"player_cell": Vector2i(4, 13),
		"walls": [
			Rect2i(16, 7, 6, 2), Rect2i(26, 7, 6, 2),
			Rect2i(16, 18, 6, 2), Rect2i(26, 18, 6, 2),
			Rect2i(16, 9, 2, 4), Rect2i(16, 16, 2, 2),
			Rect2i(30, 9, 2, 4), Rect2i(30, 16, 2, 2),
		],
		"spawns": [
			{"type": "grunt", "cell": Vector2i(23, 13)},
			{"type": "grunt", "cell": Vector2i(23, 10)},
			{"type": "drone", "cell": Vector2i(4, 4)},
			{"type": "drone", "cell": Vector2i(4, 22)},
			{"type": "grunt", "cell": Vector2i(43, 13)},
			{"type": "drone", "cell": Vector2i(43, 4)},
			{"type": "grunt", "cell": Vector2i(43, 22)},
		],
	},
	{
		"name": "LEVEL 8 - SPLIT",
		"desc": "One long wall, two doors, and a brute behind it.",
		"player_cell": Vector2i(4, 13),
		"walls": [Rect2i(23, 1, 2, 8), Rect2i(23, 12, 2, 6), Rect2i(23, 22, 2, 3)],
		"spawns": [
			{"type": "grunt", "cell": Vector2i(8, 5)},
			{"type": "drone", "cell": Vector2i(12, 20)},
			{"type": "grunt", "cell": Vector2i(38, 5)},
			{"type": "brute", "cell": Vector2i(40, 20)},
			{"type": "grunt", "cell": Vector2i(43, 13)},
			{"type": "drone", "cell": Vector2i(16, 13)},
		],
	},
	{
		"name": "LEVEL 9 - THE RING",
		"desc": "A hollow ring with one way in. Two are trapped inside.",
		"player_cell": Vector2i(4, 13),
		"walls": [
			Rect2i(14, 6, 8, 2), Rect2i(26, 6, 8, 2),
			Rect2i(14, 19, 20, 2),
			Rect2i(14, 8, 2, 11), Rect2i(32, 8, 2, 11),
		],
		"spawns": [
			{"type": "grunt", "cell": Vector2i(24, 10)},
			{"type": "drone", "cell": Vector2i(20, 15)},
			{"type": "drone", "cell": Vector2i(4, 4)},
			{"type": "grunt", "cell": Vector2i(44, 4)},
			{"type": "drone", "cell": Vector2i(44, 22)},
			{"type": "grunt", "cell": Vector2i(4, 22)},
		],
	},
	{
		"name": "LEVEL 10 - DIAGONAL",
		"desc": "A staircase of blocks. Keep moving.",
		"player_cell": Vector2i(4, 13),
		"walls": [
			Rect2i(6, 6, 3, 3), Rect2i(11, 9, 3, 3), Rect2i(16, 12, 3, 3),
			Rect2i(21, 15, 3, 3), Rect2i(26, 18, 3, 3), Rect2i(31, 15, 3, 3),
			Rect2i(36, 12, 3, 3), Rect2i(41, 9, 3, 3),
		],
		"spawns": [
			{"type": "drone", "cell": Vector2i(10, 4)},
			{"type": "drone", "cell": Vector2i(38, 4)},
			{"type": "grunt", "cell": Vector2i(24, 4)},
			{"type": "brute", "cell": Vector2i(24, 22)},
			{"type": "drone", "cell": Vector2i(10, 22)},
			{"type": "grunt", "cell": Vector2i(38, 22)},
		],
	},
	{
		"name": "LEVEL 11 - THE VAULT",
		"desc": "A sealed vault with one door. Two brutes are inside.",
		"player_cell": Vector2i(24, 22),
		"walls": [
			Rect2i(16, 9, 16, 2),
			Rect2i(16, 16, 5, 2), Rect2i(27, 16, 5, 2),
			Rect2i(16, 11, 2, 5), Rect2i(30, 11, 2, 5),
		],
		"spawns": [
			{"type": "brute", "cell": Vector2i(24, 13)},
			{"type": "drone", "cell": Vector2i(20, 13)},
			{"type": "brute", "cell": Vector2i(6, 4)},
			{"type": "drone", "cell": Vector2i(42, 4)},
			{"type": "grunt", "cell": Vector2i(4, 13)},
			{"type": "drone", "cell": Vector2i(44, 13)},
			{"type": "grunt", "cell": Vector2i(6, 22)},
			{"type": "grunt", "cell": Vector2i(44, 22)},
		],
	},
	{
		"name": "LEVEL 12 - LAST STAND",
		"desc": "Eight blocks, ten aliens, one of you.",
		"player_cell": Vector2i(2, 13),
		"walls": [
			Rect2i(6, 5, 3, 3), Rect2i(16, 5, 3, 3), Rect2i(26, 5, 3, 3), Rect2i(36, 5, 3, 3),
			Rect2i(6, 19, 3, 3), Rect2i(16, 19, 3, 3), Rect2i(26, 19, 3, 3), Rect2i(36, 19, 3, 3),
			Rect2i(22, 12, 4, 3),
		],
		"spawns": [
			{"type": "drone", "cell": Vector2i(11, 3)},
			{"type": "grunt", "cell": Vector2i(21, 3)},
			{"type": "drone", "cell": Vector2i(31, 3)},
			{"type": "grunt", "cell": Vector2i(41, 3)},
			{"type": "brute", "cell": Vector2i(11, 23)},
			{"type": "grunt", "cell": Vector2i(21, 23)},
			{"type": "brute", "cell": Vector2i(31, 23)},
			{"type": "drone", "cell": Vector2i(41, 23)},
			{"type": "grunt", "cell": Vector2i(24, 9)},
			{"type": "grunt", "cell": Vector2i(24, 17)},
		],
	},
]

## Centre of a tile cell in world pixels.
static func cell_to_world(cell: Vector2i) -> Vector2:
	return Vector2(cell) * TILE + Vector2(TILE, TILE) * 0.5
