class_name Roster
extends RefCounted

## Playable fighters and the enemies they fight.
## The menu reads this for the selection screen and the gameplay scenes read it
## for the stats, so all tuning happens in this one file.

const CHARACTERS: Array[Dictionary] = [
	{
		"id": "classic",
		"radius": 20.0,
		"name": "CLASSIC",
		"sprite": "res://alien.png",
		"health": 5,
		"speed": 330.0,
		"cooldown": 0.22,
		"bullet_speed": 700.0,
		"damage": 1,
		"desc": "Balanced all-rounder. 5 HP, steady fire.",
	},
	{
		"id": "scout",
		"radius": 17.0,
		"name": "SCOUT",
		"sprite": "res://assets/generated/scout.png",
		"health": 3,
		"speed": 430.0,
		"cooldown": 0.13,
		"bullet_speed": 780.0,
		"damage": 1,
		"desc": "Fast and fragile. 3 HP, rapid fire - hard to hit.",
	},
	{
		"id": "heavy",
		"radius": 24.0,
		"name": "HEAVY",
		"sprite": "res://assets/generated/heavy.png",
		"health": 9,
		"speed": 230.0,
		"cooldown": 0.42,
		"bullet_speed": 620.0,
		"damage": 2,
		"desc": "Slow tank. 9 HP, double damage, sluggish.",
	},
	{
		"id": "sniper",
		"radius": 18.0,
		"name": "SNIPER",
		"sprite": "res://assets/generated/sniper.png",
		"health": 4,
		"speed": 300.0,
		"cooldown": 0.55,
		"bullet_speed": 1150.0,
		"damage": 2,
		"desc": "4 HP, slow fire, very fast double-damage shots.",
	},
]

const ENEMIES: Array[Dictionary] = [
	{
		"id": "grunt",
		"radius": 19.0,
		"name": "GRUNT",
		"sprite": "res://alien.png",
		"tint": Color(1.0, 0.45, 0.45),
		"health": 2,
		"speed": 110.0,
		"fire_interval": 2.2,
		"bullet_speed": 420.0,
		"damage": 1,
		"range": 260.0,
		"desc": "The standard alien. Slow, steady single shots.",
	},
	{
		"id": "drone",
		"radius": 15.0,
		"name": "DRONE",
		"sprite": "res://assets/generated/drone.png",
		"tint": Color(1, 1, 1),
		"health": 1,
		"speed": 180.0,
		"fire_interval": 1.5,
		"bullet_speed": 480.0,
		"damage": 1,
		"range": 220.0,
		"desc": "Fast and fragile. 1 HP, fires twice as often.",
	},
	{
		"id": "brute",
		"radius": 26.0,
		"name": "BRUTE",
		"sprite": "res://assets/generated/brute.png",
		"tint": Color(1, 1, 1),
		"health": 5,
		"speed": 75.0,
		"fire_interval": 2.8,
		"bullet_speed": 380.0,
		"damage": 2,
		"range": 300.0,
		"desc": "5 HP tank. Heavy 2-damage shots, easy to outrun.",
	},
]

static func character(id: String) -> Dictionary:
	for entry in CHARACTERS:
		if entry["id"] == id:
			return entry
	return CHARACTERS[0]

static func enemy(id: String) -> Dictionary:
	for entry in ENEMIES:
		if entry["id"] == id:
			return entry
	return ENEMIES[0]

## "mixed" keeps whatever the level designer placed; any other choice overrides it.
static func resolve_enemy(spawn_type: String) -> String:
	if GameState.enemy_id == "mixed":
		return spawn_type
	return GameState.enemy_id
