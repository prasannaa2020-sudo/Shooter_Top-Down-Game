class_name LevelPlayer
extends CharacterBody2D

## The alien the player controls: aims at the mouse, shoots with click/space,
## moves with WASD or the arrow keys, and takes damage from enemy bullets.

signal health_changed(health: int, max_health: int)
signal died
signal dash_state_changed(ready: bool)

const WALL_LAYER := 1
const ENEMY_LAYER := 4
const PLAYER_BULLET_MASK := WALL_LAYER | ENEMY_LAYER

const DASH_SPEED := 1050.0
const DASH_TIME := 0.16
const DASH_COOLDOWN := 1.2
const DASH_TINT := Color(0.6, 0.95, 1.0)

@export var speed: float = 330.0
@export var max_health: int = 5
@export var fire_cooldown: float = 0.22
@export var bullet_scene: PackedScene

const PLAYER_HEIGHT := 58.0

@onready var sprite: Sprite2D = $Sprite2D
@onready var muzzle: Marker2D = $Muzzle
@onready var collision_shape: CollisionShape2D = $CollisionShape2D

var health: int = 0
var alive: bool = true

var _cooldown: float = 0.0
var _invulnerable: float = 0.0
var _bullet_speed: float = 700.0
var _damage: int = 1
var _dash_time: float = 0.0
var _dash_cooldown: float = 0.0
var _dash_dir: Vector2 = Vector2.RIGHT

func _ready() -> void:
	_apply_character(Roster.character(GameState.character_id))

## Takes the stats and the sprite of the fighter chosen in the menu.
func _apply_character(data: Dictionary) -> void:
	speed = data["speed"]
	max_health = data["health"]
	fire_cooldown = data["cooldown"]
	_bullet_speed = data["bullet_speed"]
	_damage = data["damage"]
	health = max_health
	var texture: Texture2D = load(data["sprite"])
	if texture != null:
		sprite.texture = texture
		if texture.get_height() > 0:
			sprite.scale = Vector2.ONE * (PLAYER_HEIGHT / float(texture.get_height()))
	var circle: CircleShape2D = CircleShape2D.new()
	circle.radius = data["radius"]
	collision_shape.shape = circle

func _physics_process(delta: float) -> void:
	_aim_at_mouse()

	var input_dir: Vector2 = Input.get_vector("move_left", "move_right", "move_up", "move_down")

	var was_ready: bool = _dash_cooldown <= 0.0
	_dash_cooldown = maxf(_dash_cooldown - delta, 0.0)
	if not was_ready and _dash_cooldown <= 0.0:
		dash_state_changed.emit(true)

	if Input.is_action_just_pressed("dash") and _dash_cooldown <= 0.0:
		_start_dash(input_dir)

	if _dash_time > 0.0:
		_dash_time -= delta
		velocity = _dash_dir * DASH_SPEED
		move_and_slide()
		if _dash_time <= 0.0:
			sprite.modulate = Color.WHITE
	else:
		velocity = input_dir * speed
		move_and_slide()

	_cooldown = maxf(_cooldown - delta, 0.0)
	_invulnerable = maxf(_invulnerable - delta, 0.0)
	if Input.is_action_pressed("shoot") and _cooldown <= 0.0:
		shoot()

## Short burst of speed in the movement direction - or straight ahead when standing
## still - with brief invulnerability, so it doubles as a dodge.
func _start_dash(input_dir: Vector2) -> void:
	_dash_dir = input_dir.normalized() if input_dir.length_squared() > 0.01 else transform.x.normalized()
	_dash_time = DASH_TIME
	_dash_cooldown = DASH_COOLDOWN
	_invulnerable = maxf(_invulnerable, DASH_TIME + 0.05)
	sprite.modulate = DASH_TINT
	dash_state_changed.emit(false)

func _aim_at_mouse() -> void:
	var target: Vector2 = get_global_mouse_position()
	if global_position.distance_squared_to(target) > 4.0:
		look_at(target)

func shoot() -> void:
	if bullet_scene == null:
		return
	_cooldown = fire_cooldown
	var bullet: Projectile = bullet_scene.instantiate() as Projectile
	bullet.speed = _bullet_speed
	bullet.damage = _damage
	get_parent().add_child(bullet)
	bullet.launch(muzzle.global_position, transform.x, PLAYER_BULLET_MASK, self)

func take_damage(amount: int, _source: Node = null) -> void:
	if not alive or _invulnerable > 0.0:
		return
	health = maxi(health - amount, 0)
	_invulnerable = 0.6
	health_changed.emit(health, max_health)
	_flash()
	if health <= 0:
		alive = false
		set_physics_process(false)
		died.emit()

func _flash() -> void:
	sprite.modulate = Color(1.0, 0.35, 0.35)
	var tween: Tween = create_tween()
	tween.tween_property(sprite, "modulate", Color.WHITE, 0.3)
