class_name GameState
extends RefCounted

## Menu selections that survive the scene change into a level.
## Static vars live on the script, so no autoload is needed.

static var level_index: int = 0
static var character_id: String = "classic"
static var enemy_id: String = "mixed"
