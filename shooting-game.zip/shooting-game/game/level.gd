class_name Level
extends Node2D

## Level controller.
##
## build_from_data = true  -> res://game/level.tscn: walls and enemies are built
##   from LevelData, and the level / fighter / enemy type come from GameState.
## build_from_data = false -> the hand-painted level_1/2/3.tscn: the scene's own
##   tilemap and placed enemies are used, with next_level_path for progression.

const ENEMY_SCENE := preload("res://game/enemy.tscn")
const WALL_SOURCE := 0
const WALL_ATLAS := Vector2i(0, 0)

@export var build_from_data: bool = true
@export var level_name: String = ""
@export var next_level_path: String = ""
@export var menu_path: String = "res://ui/main_menu.tscn"

@onready var floor_rect: ColorRect = $Floor
@onready var walls: TileMapLayer = $Walls
@onready var player: LevelPlayer = $Player
@onready var enemies: Node2D = $Enemies
@onready var hud: Hud = $HUD

var _enemies_left: int = 0
var _finished: bool = false
var _level_index: int = -1

func _ready() -> void:
	if build_from_data:
		_build_level(_current_index())
	else:
		_apply_enemy_override()

	_enemies_left = enemies.get_child_count()
	hud.set_level_name(level_name)
	hud.set_enemies(_enemies_left)
	hud.set_health(player.health, player.max_health)

	player.health_changed.connect(hud.set_health)
	player.died.connect(_on_player_died)
	player.dash_state_changed.connect(hud.set_dash_ready)
	hud.set_dash_ready(true)
	for child in enemies.get_children():
		var enemy: Enemy = child as Enemy
		if enemy != null:
			enemy.died.connect(_on_enemy_died)

	hud.menu_pressed.connect(_go_to_menu)
	hud.retry_pressed.connect(_retry)
	hud.next_pressed.connect(_go_to_next_level)

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel") and not _finished:
		_go_to_menu()

func _on_enemy_died(_enemy: Enemy) -> void:
	_enemies_left = maxi(_enemies_left - 1, 0)
	hud.set_enemies(_enemies_left)
	if _enemies_left <= 0:
		_finish(true)

func _on_player_died() -> void:
	_finish(false)

func _finish(won: bool) -> void:
	if _finished:
		return
	_finished = true
	get_tree().paused = true
	if won:
		var has_next: bool = _has_next_level()
		var subtitle: String = "You cleared %s." % level_name
		if not has_next:
			subtitle = "You cleared the last map. Nice shooting!"
		hud.show_result("LEVEL COMPLETE", subtitle, has_next, false)
	else:
		hud.show_result("YOU DIED", "The aliens got you. Try again.", false, true)

func _retry() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()

func _go_to_menu() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file(menu_path)

func _go_to_next_level() -> void:
	get_tree().paused = false
	if build_from_data:
		GameState.level_index = _current_index() + 1
		get_tree().reload_current_scene()
	elif next_level_path == "":
		get_tree().change_scene_to_file(menu_path)
	else:
		get_tree().change_scene_to_file(next_level_path)

func _current_index() -> int:
	return clampi(GameState.level_index, 0, LevelData.LEVELS.size() - 1)

func _has_next_level() -> bool:
	if build_from_data:
		return _level_index < LevelData.LEVELS.size() - 1
	return next_level_path != ""

## Builds one LevelData map: outer border, wall rectangles, player start, spawns.
func _build_level(index: int) -> void:
	_level_index = index
	var data: Dictionary = LevelData.LEVELS[index]
	level_name = data["name"]

	var cells: Vector2i = LevelData.ARENA
	walls.clear()
	for x in cells.x:
		_set_wall(Vector2i(x, 0))
		_set_wall(Vector2i(x, cells.y - 1))
	for y in range(1, cells.y - 1):
		_set_wall(Vector2i(0, y))
		_set_wall(Vector2i(cells.x - 1, y))
	for rect in data["walls"]:
		var r: Rect2i = rect
		for x in range(r.position.x, r.end.x):
			for y in range(r.position.y, r.end.y):
				_set_wall(Vector2i(x, y))

	player.position = LevelData.cell_to_world(data["player_cell"])
	floor_rect.color = Color.from_hsv(fmod(0.56 + index * 0.06, 1.0), 0.4, 0.13)

	for spawn in data["spawns"]:
		var enemy: Enemy = ENEMY_SCENE.instantiate() as Enemy
		enemy.enemy_type = Roster.resolve_enemy(spawn["type"])
		enemy.position = LevelData.cell_to_world(spawn["cell"])
		enemies.add_child(enemy)

func _set_wall(cell: Vector2i) -> void:
	walls.set_cell(cell, WALL_SOURCE, WALL_ATLAS)

## Hand-painted levels keep the enemy stats saved in the scene, but a specific
## enemy type chosen in the menu still overrides them.
func _apply_enemy_override() -> void:
	if GameState.enemy_id == "mixed":
		return
	for child in enemies.get_children():
		var enemy: Enemy = child as Enemy
		if enemy != null:
			enemy.apply_type(GameState.enemy_id)
