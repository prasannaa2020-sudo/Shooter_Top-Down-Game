class_name Enemy
extends CharacterBody2D

## An alien that strafes around the player and shoots at it.
## It glows yellow for WARNING_TIME before firing, so the player can dodge.

signal died(enemy: Enemy)

const WALL_LAYER := 1
const PLAYER_LAYER := 2
const ENEMY_BULLET_MASK := WALL_LAYER | PLAYER_LAYER
const WARNING_TIME := 0.4

const ENEMY_HEIGHT := 54.0

@export var enemy_type: String = ""
@export var speed: float = 110.0
@export var max_health: int = 2
@export var fire_interval: float = 2.2
@export var bullet_speed: float = 420.0
@export var bullet_damage: int = 1
@export var preferred_range: float = 260.0
@export var tint: Color = Color(1.0, 0.45, 0.45)
@export var bullet_scene: PackedScene

@onready var sprite: Sprite2D = $Sprite2D
@onready var muzzle: Marker2D = $Muzzle
@onready var collision_shape: CollisionShape2D = $CollisionShape2D

var health: int = 0

var _move_dir: Vector2 = Vector2.RIGHT
var _turn_timer: float = 0.0
var _fire_timer: float = 0.0
var _warning: bool = false
var _player: LevelPlayer = null

func _ready() -> void:
	if enemy_type != "":
		apply_type(enemy_type)
	else:
		health = max_health
		sprite.self_modulate = tint
	_fire_timer = randf_range(fire_interval * 0.5, fire_interval)
	_pick_move_direction()

## Copies the stats and the sprite of one Roster.ENEMIES entry.
func apply_type(type_id: String) -> void:
	enemy_type = type_id
	var data: Dictionary = Roster.enemy(type_id)
	speed = data["speed"]
	max_health = data["health"]
	fire_interval = data["fire_interval"]
	bullet_speed = data["bullet_speed"]
	bullet_damage = data["damage"]
	preferred_range = data["range"]
	tint = data["tint"]
	health = max_health
	var texture: Texture2D = load(data["sprite"])
	if texture != null:
		sprite.texture = texture
		if texture.get_height() > 0:
			sprite.scale = Vector2.ONE * (ENEMY_HEIGHT / float(texture.get_height()))
	sprite.self_modulate = tint
	var circle: CircleShape2D = CircleShape2D.new()
	circle.radius = data["radius"]
	collision_shape.shape = circle

func _physics_process(delta: float) -> void:
	_player = _find_player()

	_turn_timer -= delta
	if _turn_timer <= 0.0:
		_pick_move_direction()

	if _player != null:
		var to_player: Vector2 = _player.global_position - global_position
		if to_player.length_squared() > 4.0:
			rotation = to_player.angle()

	velocity = _move_dir * speed
	move_and_slide()
	_bounce_off_walls()
	_update_shooting(delta)

func take_damage(amount: int, _source: Node = null) -> void:
	if health <= 0:
		return
	health -= amount
	if health <= 0:
		died.emit(self)
		queue_free()
		return
	sprite.self_modulate = Color.WHITE
	var tween: Tween = create_tween()
	tween.tween_property(sprite, "self_modulate", tint, 0.25)

func _find_player() -> LevelPlayer:
	if _player != null and is_instance_valid(_player):
		return _player
	return get_tree().get_first_node_in_group("player") as LevelPlayer

func _pick_move_direction() -> void:
	_turn_timer = randf_range(0.9, 1.8)
	var player: LevelPlayer = _find_player()
	if player == null:
		_move_dir = Vector2.RIGHT.rotated(randf_range(0.0, TAU))
		return

	var to_player: Vector2 = player.global_position - global_position
	var distance: float = to_player.length()
	var radial: Vector2 = Vector2.ZERO
	if distance > preferred_range + 60.0:
		radial = to_player.normalized() * 1.4
	elif distance < preferred_range - 60.0:
		radial = -to_player.normalized() * 1.4

	# Circle the player (strafe) while closing in or backing off.
	var tangent: Vector2 = to_player.normalized().orthogonal()
	if randf() < 0.5:
		tangent = -tangent
	_move_dir = (tangent * 1.2 + radial).normalized()

func _bounce_off_walls() -> void:
	for i in get_slide_collision_count():
		var collision: KinematicCollision2D = get_slide_collision(i)
		var normal: Vector2 = collision.get_normal()
		if absf(normal.dot(_move_dir)) > 0.2:
			_move_dir = _move_dir.bounce(normal).normalized()
			_turn_timer = maxf(_turn_timer, 0.6)

func _update_shooting(delta: float) -> void:
	if bullet_scene == null or _player == null:
		return
	_fire_timer -= delta
	if not _warning and _fire_timer <= WARNING_TIME:
		_warning = true
		sprite.modulate = Color(1.0, 0.85, 0.35)
	if _fire_timer <= 0.0:
		_fire_timer = fire_interval
		_warning = false
		sprite.modulate = Color.WHITE
		_fire()

func _fire() -> void:
	var to_player: Vector2 = _player.global_position - muzzle.global_position
	if to_player.length_squared() < 1.0:
		return
	var bullet: Projectile = bullet_scene.instantiate() as Projectile
	bullet.speed = bullet_speed
	bullet.damage = bullet_damage
	get_parent().add_child(bullet)
	bullet.launch(muzzle.global_position, to_player.normalized(), ENEMY_BULLET_MASK, self)
