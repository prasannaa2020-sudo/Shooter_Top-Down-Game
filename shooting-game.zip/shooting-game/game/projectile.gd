class_name Projectile
extends CharacterBody2D

## Bouncing bullet shared by the player and the enemies.
##
## Physics layers: 1 = walls, 2 = player, 3 = enemies (value 4), 4 = bullets.
## launch() sets the collision mask, so a bullet can never hit whoever fired it.

const WALL_LAYER := 1
const ENEMY_LAYER := 4

@export var speed: float = 700.0
@export var max_bounces: int = 2
@export var damage: int = 1

var direction: Vector2 = Vector2.RIGHT
var bounces: int = 0
var shooter: Node = null

func _ready() -> void:
	direction = transform.x.normalized()

## Fires the bullet from a position towards a direction, hitting only target_mask.
func launch(from_position: Vector2, dir: Vector2, target_mask: int, fired_by: Node) -> void:
	global_position = from_position
	direction = dir.normalized()
	rotation = direction.angle()
	collision_mask = target_mask
	shooter = fired_by

func _physics_process(delta: float) -> void:
	var collision: KinematicCollision2D = move_and_collide(direction * speed * delta)
	if collision == null:
		return

	var target: Object = collision.get_collider()
	if target != null and target.has_method("take_damage"):
		target.take_damage(damage, self)
		queue_free()
		return

	# Hit a wall: ricochet up to max_bounces times, then vanish.
	bounces += 1
	if bounces > max_bounces:
		queue_free()
		return

	direction = direction.bounce(collision.get_normal())
	rotation = direction.angle()
