extends CharacterBody2D

@onready var bullet_template = get_parent().get_node("bullet")
var knockback = Vector2.ZERO

func _physics_process(delta):
	look_at(get_global_mouse_position())
	
	if Input.is_action_just_pressed("ui_accept"):
		shoot()

	var input_direction = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	knockback = knockback.move_toward(Vector2.ZERO, 1500 * delta)
	velocity = (input_direction * 400) + knockback
	
	if move_and_slide():
		knockback = get_wall_normal() * 1000

func shoot():
	var bullet = bullet_template.duplicate()
	bullet.visible = true
	bullet.global_position = global_position + (transform.x * 10)
	bullet.global_rotation = global_rotation
	get_parent().add_child(bullet)
