class_name BouncingBullet
extends CharacterBody2D

## Bullet that ricochets off walls and frees itself after MAX_BOUNCES hits.

const SPEED := 800.0
const MAX_BOUNCES := 2

var direction: Vector2 = Vector2.RIGHT
var bounces: int = 0

func _ready() -> void:
	direction = transform.x.normalized()

func _physics_process(delta: float) -> void:
	if not visible:
		return
	
	var collision: KinematicCollision2D = move_and_collide(direction * SPEED * delta)
	if collision == null:
		return

	bounces += 1
	if bounces > MAX_BOUNCES:
		queue_free()
		return

	direction = direction.bounce(collision.get_normal())
	rotation = direction.angle()
	
